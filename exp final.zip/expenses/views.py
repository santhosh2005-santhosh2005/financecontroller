from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Expense, CategoryBudget
from .forms import AddExpenseForm, EditExpenseForm
from users.models import UserProfile
from django.http import JsonResponse
from django.db.models import Sum, Count
from django.utils import timezone
from datetime import datetime, timedelta
from decimal import Decimal
import calendar
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
import json

@login_required
def expense_list(request):
    expenses = Expense.objects.filter(user=request.user)
    total_expenses = sum(expense.amount for expense in expenses)
    
    # Safely get user profile, create one if it doesn't exist
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        balance = user_profile.salary - total_expenses
    except UserProfile.DoesNotExist:
        # Create a default user profile if it doesn't exist
        user_profile = UserProfile.objects.create(user=request.user, salary=0)
        balance = 0
    
    form = AddExpenseForm(user=request.user)
    return render(request, 'expenses/expense_list.html', {
        'expenses': expenses,
        'total_expenses': total_expenses,
        'balance': balance,
        'form': form,
    })

@login_required
def add_expense(request):
    if request.method == 'POST':
        form = AddExpenseForm(request.POST, user=request.user)
        if form.is_valid():
            form.save()
            return redirect('expenses:expense_list')
        else:
            # For debugging form errors
            print(form.errors)
    else:
        emi_amount = request.GET.get('emi_amount')
        category = request.GET.get('category')
        amount = request.GET.get('amount')
        initial_data = {}
        if emi_amount:
            initial_data['emi_amount'] = emi_amount
        if category:
            initial_data['category'] = category
        if amount:
            initial_data['amount'] = amount
        form = AddExpenseForm(user=request.user, initial=initial_data)

    return render(request, 'expenses/add_expense.html', {'form': form})

@login_required
def edit_expense(request, pk):
    expense = get_object_or_404(Expense, id=pk, user=request.user)
    if request.method == 'POST':
        expense_form = EditExpenseForm(request.POST, instance=expense)
        if expense_form.is_valid():
            expense_form.save()
            return redirect('expenses:expense_list')
    else:
        expense_form = EditExpenseForm(instance=expense)
    return render(request, 'expenses/edit_expense.html', {'expense_form': expense_form, 'expense': expense})

@login_required
def delete_expense(request, pk):
    expense = get_object_or_404(Expense, id=pk, user=request.user)
    if request.method == 'POST':
        expense.delete()
        return redirect('expenses:expense_list')
    return render(request, 'expenses/delete_expense.html', {'expense': expense})

@login_required
def expense_chart_data(request):
    expenses = Expense.objects.filter(user=request.user)
    categories = {}
    for expense in expenses:
        if expense.category in categories:
            categories[expense.category] += expense.amount
        else:
            categories[expense.category] = expense.amount
    return JsonResponse(categories)

@login_required
def expense_detail(request, pk):
    expense = get_object_or_404(Expense, pk=pk, user=request.user)
    return render(request, 'expenses/expense_detail.html', {'expense': expense})

@login_required
def reports(request):
    # Get date range from request or default to current month
    period = request.GET.get('period', 'month')
    
    if period == 'week':
        start_date = timezone.now().date() - timedelta(days=7)
    elif period == 'month':
        start_date = timezone.now().date().replace(day=1)
    elif period == 'year':
        start_date = timezone.now().date().replace(month=1, day=1)
    else:
        start_date = timezone.now().date() - timedelta(days=30)
    
    end_date = timezone.now().date()
    
    # Get expenses for the period
    expenses = Expense.objects.filter(
        user=request.user,
        date__range=[start_date, end_date]
    )
    
    # Calculate statistics
    total_expenses = expenses.aggregate(total=Sum('amount'))['total'] or 0
    total_emi = expenses.aggregate(total=Sum('emi_amount'))['total'] or 0
    expense_count = expenses.count()
    
    # Category breakdown
    category_stats = expenses.values('category').annotate(
        total=Sum('amount'),
        count=Count('id')
    ).order_by('-total')
    
    # Monthly trend data
    monthly_data = []
    current_date = start_date
    while current_date <= end_date:
        month_expenses = expenses.filter(
            date__year=current_date.year,
            date__month=current_date.month
        ).aggregate(total=Sum('amount'))['total'] or 0
        monthly_data.append({
            'month': current_date.strftime('%B %Y'),
            'total': float(month_expenses)
        })
        current_date = (current_date.replace(day=1) + timedelta(days=32)).replace(day=1)
    
    # Get user profile for salary info
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        salary = user_profile.salary
        remaining_budget = salary - total_expenses
    except UserProfile.DoesNotExist:
        salary = 0
        remaining_budget = 0
    
    context = {
        'period': period,
        'start_date': start_date,
        'end_date': end_date,
        'total_expenses': total_expenses,
        'total_emi': total_emi,
        'expense_count': expense_count,
        'category_stats': category_stats,
        'monthly_data': monthly_data,
        'salary': salary,
        'remaining_budget': remaining_budget,
        'expenses': expenses[:10],  # Recent expenses
    }
    
    return render(request, 'expenses/reports.html', context)

@login_required
def budget(request):
    # Get user profile
    try:
        user_profile = UserProfile.objects.get(user=request.user)
        monthly_salary = user_profile.salary
    except UserProfile.DoesNotExist:
        monthly_salary = 0
    
    # Get current month (first day)
    current_month = timezone.now().date().replace(day=1)
    current_month_expenses = Expense.objects.filter(
        user=request.user,
        date__gte=current_month
    ).aggregate(total=Sum('amount'))['total'] or 0

    # Handle POST for setting category budgets
    if request.method == 'POST' and 'set_category_budget' in request.POST:
        cat = request.POST.get('category')
        amt = request.POST.get('amount')
        if cat and amt:
            try:
                amt = Decimal(amt)
                cb, created = CategoryBudget.objects.get_or_create(
                    user=request.user, category=cat, month=current_month,
                    defaults={'amount': amt}
                )
                if not created:
                    cb.amount = amt
                    cb.save()
            except Exception as e:
                pass  # Optionally add error handling

    # Flexible category mapping
    category_aliases = {
        'Food & Dining': ['Food', 'Dining', 'Groceries', 'Food & Dining'],
        'Transportation': ['Transport', 'Transportation', 'Commute'],
        'Shopping': ['Shopping', 'Clothes', 'Apparel'],
        'Entertainment': ['Entertainment', 'Movies', 'Leisure'],
        'Utilities': ['Utilities', 'Bills', 'Electricity', 'Water'],
        'Healthcare': ['Healthcare', 'Medical', 'Doctor', 'Medicine'],
        'Savings': ['Savings', 'Investments', 'Deposit'],
    }
    default_budget_categories = {
        'Food & Dining': Decimal('0.25'),
        'Transportation': Decimal('0.15'),
        'Shopping': Decimal('0.20'),
        'Entertainment': Decimal('0.10'),
        'Utilities': Decimal('0.15'),
        'Healthcare': Decimal('0.10'),
        'Savings': Decimal('0.05'),
    }

    # Calculate actual spending by category for current month (flexible)
    category_spending = {}
    for budget_cat, aliases in category_aliases.items():
        category_expenses = Expense.objects.filter(
            user=request.user,
            date__gte=current_month,
            category__in=aliases
        ).aggregate(total=Sum('amount'))['total'] or 0
        category_spending[budget_cat] = category_expenses

    # Calculate budget vs actual, using user-set budget if available
    budget_analysis = []
    for category, percentage in default_budget_categories.items():
        # Check for user-set budget
        user_budget_obj = CategoryBudget.objects.filter(user=request.user, category=category, month=current_month).first()
        if user_budget_obj:
            budget_amount = user_budget_obj.amount
        else:
            budget_amount = monthly_salary * percentage
        actual_amount = category_spending.get(category, 0)
        remaining = budget_amount - actual_amount
        usage_percentage = (actual_amount / budget_amount * 100) if budget_amount > 0 else 0
        budget_analysis.append({
            'category': category,
            'budget': budget_amount,
            'actual': actual_amount,
            'remaining': remaining,
            'usage_percentage': usage_percentage,
            'status': 'danger' if actual_amount > budget_amount else 'warning' if usage_percentage > 80 else 'good'
        })

    # Savings goal tracking
    savings_goal = monthly_salary * Decimal('0.20')  # 20% savings goal
    remaining_budget = monthly_salary - current_month_expenses
    current_savings = remaining_budget if remaining_budget > 0 else 0
    savings_percentage = (current_savings / savings_goal * 100) if savings_goal > 0 else 0

    context = {
        'monthly_salary': monthly_salary,
        'current_month_expenses': current_month_expenses,
        'remaining_budget': remaining_budget,
        'budget_analysis': budget_analysis,
        'savings_goal': savings_goal,
        'current_savings': current_savings,
        'savings_percentage': savings_percentage,
        'current_month': current_month.strftime('%B %Y'),
        'current_month_date': current_month,
    }

    return render(request, 'expenses/budget.html', context)

@login_required
@require_POST
@csrf_exempt  # We'll use JS to send CSRF token, but for AJAX, this is sometimes needed
def api_add_expense(request):
    try:
        data = json.loads(request.body.decode('utf-8'))
        category = data.get('category')
        amount = data.get('amount')
        description = data.get('description', '')
        emi_amount = data.get('emi_amount', 0)
        if not category or not amount:
            return JsonResponse({'success': False, 'error': 'Category and amount are required.'}, status=400)
        from .models import Expense
        expense = Expense.objects.create(
            user=request.user,
            category=category,
            amount=amount,
            description=description,
            emi_amount=emi_amount
        )
        return JsonResponse({'success': True, 'expense': {
            'id': expense.id,
            'category': expense.category,
            'amount': str(expense.amount),
            'description': expense.description,
            'emi_amount': str(expense.emi_amount),
            'date': expense.date.strftime('%Y-%m-%d'),
        }})
    except Exception as e:
        return JsonResponse({'success': False, 'error': str(e)}, status=500)
