from django import forms
from .models import Expense

class AddExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['category', 'amount', 'description', 'emi_amount']

    def __init__(self, *args, **kwargs):
        self.user = kwargs.pop('user', None)
        super().__init__(*args, **kwargs)
        self.fields['emi_amount'] = forms.DecimalField(max_digits=10, decimal_places=2, required=False, initial=kwargs.get('initial', {}).get('emi_amount', 0))

    def save(self, commit=True):
        expense = super().save(commit=False)
        if self.user:
            expense.user = self.user
        if commit:
            expense.save()
        return expense

    def clean(self):
        cleaned_data = super().clean()
        emi_amount = cleaned_data.get('emi_amount')
        if emi_amount in [None, '']:
            cleaned_data['emi_amount'] = 0
        return cleaned_data

class EditExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        fields = ['category', 'amount', 'description']

class LoginForm(forms.Form):
    username = forms.CharField(max_length=150)
    password = forms.CharField(widget=forms.PasswordInput)

class EMICalculatorForm(forms.Form):
    loan_amount = forms.DecimalField(label='Loan Amount', max_digits=10, decimal_places=2)
    interest_rate = forms.DecimalField(label='Interest Rate', max_digits=5, decimal_places=2)
    loan_period = forms.IntegerField(label='Loan Period (Years)')
