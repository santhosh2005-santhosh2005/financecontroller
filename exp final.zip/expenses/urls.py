from django.urls import path
from . import views

app_name = 'expenses'

urlpatterns = [
    path('', views.expense_list, name='expense_list'),
    path('add/', views.add_expense, name='add_expense'),
    path('edit/<int:pk>/', views.edit_expense, name='edit_expense'),
    path('delete/<int:pk>/', views.delete_expense, name='delete_expense'),
    path('detail/<int:pk>/', views.expense_detail, name='expense_detail'),
    path('chart-data/', views.expense_chart_data, name='expense_chart_data'),
    path('reports/', views.reports, name='reports'),
    path('budget/', views.budget, name='budget'),
    path('api/add/', views.api_add_expense, name='api_add_expense'),
]
