from django.apps import AppConfig


class UpiPaymentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'upi_payments'
