from django import forms
from django.contrib.auth.models import User
from .models import UPIID, UPITransaction, PaymentRequest, QRCode, BillScan, BankAccount
import re

class UPIIDForm(forms.ModelForm):
    """Form for creating/updating UPI ID"""
    class Meta:
        model = UPIID
        fields = ['upi_id', 'display_name']
        widgets = {
            'upi_id': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter your UPI ID (e.g., username@bank)'
            }),
            'display_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter display name'
            })
        }

    def clean_upi_id(self):
        upi_id = self.cleaned_data['upi_id']
        # Basic UPI ID validation
        if not re.match(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$', upi_id):
            raise forms.ValidationError("Please enter a valid UPI ID (e.g., username@bank)")
        return upi_id

class SendMoneyForm(forms.ModelForm):
    """Form for sending money via UPI"""
    class Meta:
        model = UPITransaction
        fields = ['receiver_upi', 'amount', 'description']
        widgets = {
            'receiver_upi': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter receiver UPI ID'
            }),
            'amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter amount',
                'min': '1',
                'step': '0.01'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Enter description (optional)',
                'rows': 3
            })
        }

    def clean_amount(self):
        amount = self.cleaned_data['amount']
        if amount <= 0:
            raise forms.ValidationError("Amount must be greater than 0")
        if amount > 100000:  # Limit to 1 lakh
            raise forms.ValidationError("Amount cannot exceed ₹1,00,000")
        return amount

    def clean_receiver_upi(self):
        receiver_upi = self.cleaned_data['receiver_upi']
        if not re.match(r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$', receiver_upi):
            raise forms.ValidationError("Please enter a valid UPI ID")
        return receiver_upi

class RequestMoneyForm(forms.ModelForm):
    """Form for requesting money via UPI"""
    class Meta:
        model = PaymentRequest
        fields = ['recipient', 'amount', 'description']
        widgets = {
            'recipient': forms.Select(attrs={
                'class': 'form-control'
            }),
            'amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter amount',
                'min': '1',
                'step': '0.01'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Enter description (optional)',
                'rows': 3
            })
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        # Filter users who have UPI IDs
        self.fields['recipient'].queryset = User.objects.filter(upi_id__isnull=False)

class QRCodeForm(forms.ModelForm):
    """Form for generating QR codes"""
    class Meta:
        model = QRCode
        fields = ['amount', 'description']
        widgets = {
            'amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter amount (optional)',
                'min': '1',
                'step': '0.01'
            }),
            'description': forms.Textarea(attrs={
                'class': 'form-control',
                'placeholder': 'Enter description (optional)',
                'rows': 3
            })
        }

    def clean_amount(self):
        amount = self.cleaned_data.get('amount')
        if amount and amount <= 0:
            raise forms.ValidationError("Amount must be greater than 0")
        if amount and amount > 100000:
            raise forms.ValidationError("Amount cannot exceed ₹1,00,000")
        return amount

class QRCodeScanForm(forms.Form):
    """Form for scanning QR codes"""
    qr_code_data = forms.CharField(
        widget=forms.HiddenInput(),
        required=False
    )
    scanned_amount = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        required=False,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Amount from QR code',
            'readonly': 'readonly'
        })
    )
    scanned_upi = forms.CharField(
        max_length=50,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'UPI ID from QR code',
            'readonly': 'readonly'
        })
    )
    description = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter description (optional)'
        })
    )

class UPIAmountForm(forms.Form):
    """Form for entering amount after scanning QR"""
    amount = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter amount',
            'min': '1',
            'step': '0.01'
        })
    )
    description = forms.CharField(
        max_length=200,
        required=False,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter description (optional)'
        })
    )

    def clean_amount(self):
        amount = self.cleaned_data['amount']
        if amount <= 0:
            raise forms.ValidationError("Amount must be greater than 0")
        if amount > 100000:
            raise forms.ValidationError("Amount cannot exceed ₹1,00,000")
        return amount

class BillScanForm(forms.ModelForm):
    """Form for uploading and scanning bills"""
    class Meta:
        model = BillScan
        fields = ['bill_image']
        widgets = {
            'bill_image': forms.FileInput(attrs={
                'class': 'form-control',
                'accept': 'image/*',
                'capture': 'environment'
            })
        }

    def clean_bill_image(self):
        image = self.cleaned_data.get('bill_image')
        if image:
            # Check file size (max 10MB)
            if image.size > 10 * 1024 * 1024:
                raise forms.ValidationError("Image file size must be less than 10MB")
            
            # Check file type
            allowed_types = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
            if image.content_type not in allowed_types:
                raise forms.ValidationError("Please upload a valid image file (JPEG, PNG, or WebP)")
        
        return image

class BillEditForm(forms.ModelForm):
    """Form for editing extracted bill data"""
    class Meta:
        model = BillScan
        fields = ['merchant_name', 'total_amount', 'subtotal', 'tax_amount', 'date', 'time', 'bill_number']
        widgets = {
            'merchant_name': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Enter merchant/store name'
            }),
            'total_amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Total amount',
                'step': '0.01',
                'min': '0'
            }),
            'subtotal': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Subtotal (optional)',
                'step': '0.01',
                'min': '0'
            }),
            'tax_amount': forms.NumberInput(attrs={
                'class': 'form-control',
                'placeholder': 'Tax amount (optional)',
                'step': '0.01',
                'min': '0'
            }),
            'date': forms.DateInput(attrs={
                'class': 'form-control',
                'type': 'date'
            }),
            'time': forms.TimeInput(attrs={
                'class': 'form-control',
                'type': 'time'
            }),
            'bill_number': forms.TextInput(attrs={
                'class': 'form-control',
                'placeholder': 'Bill/Receipt number'
            })
        }

    def clean_total_amount(self):
        amount = self.cleaned_data.get('total_amount')
        if amount and amount <= 0:
            raise forms.ValidationError("Total amount must be greater than 0")
        return amount

    def clean_subtotal(self):
        subtotal = self.cleaned_data.get('subtotal')
        if subtotal and subtotal <= 0:
            raise forms.ValidationError("Subtotal must be greater than 0")
        return subtotal

    def clean_tax_amount(self):
        tax = self.cleaned_data.get('tax_amount')
        if tax and tax < 0:
            raise forms.ValidationError("Tax amount cannot be negative")
        return tax

class CalculatorForm(forms.Form):
    expression = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Enter calculation (e.g. 12+7*3)'
        })
    )

class ShoppingCartItemForm(forms.Form):
    name = forms.CharField(
        max_length=100,
        widget=forms.TextInput(attrs={
            'class': 'form-control',
            'placeholder': 'Item name'
        })
    )
    price = forms.DecimalField(
        max_digits=10,
        decimal_places=2,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Price',
            'min': '0',
            'step': '0.01'
        })
    )
    quantity = forms.IntegerField(
        min_value=1,
        initial=1,
        widget=forms.NumberInput(attrs={
            'class': 'form-control',
            'placeholder': 'Qty',
            'min': '1'
        })
    )
    bought = forms.BooleanField(
        required=False,
        widget=forms.CheckboxInput(attrs={'class': 'form-check-input'})
    )

class BankAccountForm(forms.ModelForm):
    class Meta:
        model = BankAccount
        fields = ['bank_name', 'account_number', 'ifsc_code', 'is_primary']
        widgets = {
            'bank_name': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Bank Name'}),
            'account_number': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Account Number'}),
            'ifsc_code': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'IFSC Code'}),
            'is_primary': forms.CheckboxInput(attrs={'class': 'form-check-input'}),
        }

    def clean_account_number(self):
        acc = self.cleaned_data['account_number']
        if not acc.isdigit() or len(acc) < 6:
            raise forms.ValidationError('Enter a valid account number.')
        return acc

    def clean_ifsc_code(self):
        ifsc = self.cleaned_data['ifsc_code']
        if len(ifsc) < 6:
            raise forms.ValidationError('Enter a valid IFSC code.')
        return ifsc 