import qrcode
import re
from urllib.parse import urlparse, parse_qs
from io import BytesIO
from django.core.files import File
from django.conf import settings
import os
import cv2
import numpy as np
from PIL import Image
import pytesseract
import easyocr
from datetime import datetime, date
import logging
from decimal import Decimal, InvalidOperation

logger = logging.getLogger(__name__)

def generate_upi_url(upi_id, amount=None, description=None, name=None):
    """
    Generate UPI URL for QR code
    Format: upi://pay?pa=<upi_id>&pn=<name>&am=<amount>&tn=<description>
    """
    url = f"upi://pay?pa={upi_id}"
    
    if name:
        url += f"&pn={name}"
    if amount:
        url += f"&am={amount}"
    if description:
        url += f"&tn={description}"
    
    return url

def parse_upi_url(upi_url):
    """
    Parse UPI URL to extract payment details
    """
    try:
        parsed = urlparse(upi_url)
        if parsed.scheme != 'upi' or parsed.netloc != 'pay':
            return None
        
        query_params = parse_qs(parsed.query)
        
        return {
            'upi_id': query_params.get('pa', [None])[0],
            'name': query_params.get('pn', [None])[0],
            'amount': query_params.get('am', [None])[0],
            'description': query_params.get('tn', [None])[0],
        }
    except Exception:
        return None

def generate_qr_code(upi_url, filename=None):
    """
    Generate QR code image from UPI URL
    """
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(upi_url)
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    
    # Save to BytesIO
    buffer = BytesIO()
    img.save(buffer, format='PNG')
    buffer.seek(0)
    
    return buffer

def validate_upi_id(upi_id):
    """
    Validate UPI ID format
    """
    pattern = r'^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+$'
    return bool(re.match(pattern, upi_id))

def format_amount(amount):
    """
    Format amount for display
    """
    return f"₹{amount:,.2f}"

def generate_transaction_reference():
    """
    Generate unique transaction reference
    """
    import uuid
    return str(uuid.uuid4())[:8].upper()

def process_upi_payment(sender, receiver_upi, amount, description=None):
    """
    Process UPI payment (simulated)
    In a real implementation, this would integrate with actual UPI payment gateways
    """
    from .models import UPITransaction
    from django.utils import timezone
    
    # Create transaction record
    transaction = UPITransaction.objects.create(
        sender=sender,
        receiver_upi=receiver_upi,
        amount=amount,
        description=description,
        transaction_type='send',
        status='pending',
        upi_reference=generate_transaction_reference()
    )
    
    # Simulate payment processing
    # In real implementation, this would call UPI payment gateway APIs
    import random
    import time
    
    # Simulate processing delay
    time.sleep(0.5)
    
    # Simulate success/failure (90% success rate)
    success = random.random() < 0.9
    
    if success:
        transaction.status = 'success'
        transaction.completed_at = timezone.now()
    else:
        transaction.status = 'failed'
    
    transaction.save()
    
    return transaction

def get_user_upi_balance(user):
    """
    Get user's UPI balance (simulated)
    In real implementation, this would fetch from actual bank account
    """
    # Simulate balance - in real app, this would be fetched from bank API
    import random
    return random.randint(1000, 50000)

def is_valid_qr_code(qr_data):
    """
    Check if scanned QR code contains valid UPI data
    """
    if not qr_data:
        return False
    
    # Check if it's a UPI URL
    if qr_data.startswith('upi://'):
        parsed = parse_upi_url(qr_data)
        return parsed is not None and parsed.get('upi_id')
    
    # Check if it's just a UPI ID
    return validate_upi_id(qr_data)

def create_qr_code_file(upi_url, user, amount=None, description=None):
    """
    Create QR code file and save to media directory
    """
    from .models import QRCode
    
    # Generate QR code
    qr_buffer = generate_qr_code(upi_url)
    
    # Create QR code record
    qr_code = QRCode.objects.create(
        user=user,
        upi_id=user.upi_id.upi_id if hasattr(user, 'upi_id') else '',
        amount=amount,
        description=description,
        qr_data=upi_url
    )
    
    # Save QR code image
    filename = f"qr_code_{qr_code.id}.png"
    qr_code.qr_code_image.save(filename, File(qr_buffer), save=True)
    
    return qr_code

# Bill Scanning Functions
def preprocess_image(image_path):
    """
    Preprocess image for better OCR results
    """
    try:
        # Read image
        image = cv2.imread(image_path)
        if image is None:
            return None
        
        # Convert to grayscale
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        
        # Apply noise reduction
        denoised = cv2.fastNlMeansDenoising(gray)
        
        # Apply threshold to get binary image
        _, binary = cv2.threshold(denoised, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        
        # Apply morphological operations to clean up
        kernel = np.ones((1, 1), np.uint8)
        cleaned = cv2.morphologyEx(binary, cv2.MORPH_CLOSE, kernel)
        
        return cleaned
    except Exception as e:
        logger.error(f"Error preprocessing image: {e}")
        return None

def extract_text_with_tesseract(image_path):
    """
    Extract text from image using Tesseract OCR
    """
    try:
        # Preprocess image
        processed_image = preprocess_image(image_path)
        if processed_image is None:
            return None, 0.0
        
        # Extract text
        text = pytesseract.image_to_string(processed_image, lang='eng')
        
        # Get confidence score (average)
        data = pytesseract.image_to_data(processed_image, lang='eng', output_type=pytesseract.Output.DICT)
        confidences = [int(conf) for conf in data['conf'] if int(conf) > 0]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        return text.strip(), avg_confidence / 100.0
    except Exception as e:
        logger.error(f"Error extracting text with Tesseract: {e}")
        return None, 0.0

def extract_text_with_easyocr(image_path):
    """
    Extract text from image using EasyOCR
    """
    try:
        # Initialize EasyOCR reader
        reader = easyocr.Reader(['en'])
        
        # Read image
        results = reader.readtext(image_path)
        
        # Extract text
        text_lines = [result[1] for result in results]
        text = '\n'.join(text_lines)
        
        # Calculate confidence score
        confidences = [result[2] for result in results]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0.0
        
        return text.strip(), avg_confidence
    except Exception as e:
        logger.error(f"Error extracting text with EasyOCR: {e}")
        return None, 0.0

def extract_bill_data(text):
    """
    Extract bill information from OCR text
    """
    if not text:
        return {}
    
    lines = text.split('\n')
    extracted_data = {
        'merchant_name': None,
        'total_amount': None,
        'subtotal': None,
        'tax_amount': None,
        'date': None,
        'time': None,
        'bill_number': None
    }
    
    # Amount patterns
    amount_patterns = [
        r'total[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'amount[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'grand\s*total[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'net\s*payable[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'balance\s*due[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'total\s*due[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'total\s*amt[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'payable[:\s]*₹?\s*([0-9,]+\.?[0-9]*)',
        r'₹\s*([0-9,]+\.?[0-9]*)',
        r'rs\.?\s*([0-9,]+\.?[0-9]*)',
        r'rupees[:\s]*([0-9,]+\.?[0-9]*)',
    ]
    
    # Date patterns
    date_patterns = [
        r'(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})',
        r'(\d{1,2}\s+(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\s+\d{2,4})',
        r'(\d{4}-\d{2}-\d{2})',
    ]
    
    # Time patterns
    time_patterns = [
        r'(\d{1,2}:\d{2}(?::\d{2})?\s*(?:am|pm)?)',
        r'(\d{1,2}:\d{2}(?::\d{2})?)',
    ]
    
    # Bill number patterns
    bill_patterns = [
        r'bill[:\s]*#?\s*([a-zA-Z0-9-]+)',
        r'receipt[:\s]*#?\s*([a-zA-Z0-9-]+)',
        r'invoice[:\s]*#?\s*([a-zA-Z0-9-]+)',
        r'#\s*([a-zA-Z0-9-]+)',
    ]
    
    # Extract amounts
    found_amounts = []
    for line in lines:
        line_lower = line.lower()
        
        # Look for total amount
        for pattern in amount_patterns:
            match = re.search(pattern, line_lower)
            if match:
                amount_str = match.group(1).replace(',', '')
                try:
                    amount = float(amount_str)
                    if amount > 0:
                        extracted_data['total_amount'] = amount
                        found_amounts.append(amount)
                        break
                except ValueError:
                    continue
        
        # Look for subtotal
        if 'subtotal' in line_lower or 'sub total' in line_lower:
            for pattern in amount_patterns:
                match = re.search(pattern, line_lower)
                if match:
                    amount_str = match.group(1).replace(',', '')
                    try:
                        amount = float(amount_str)
                        if amount > 0:
                            extracted_data['subtotal'] = amount
                            break
                    except ValueError:
                        continue
        
        # Look for tax
        if 'tax' in line_lower or 'gst' in line_lower or 'cgst' in line_lower or 'sgst' in line_lower:
            for pattern in amount_patterns:
                match = re.search(pattern, line_lower)
                if match:
                    amount_str = match.group(1).replace(',', '')
                    try:
                        amount = float(amount_str)
                        if amount > 0:
                            extracted_data['tax_amount'] = amount
                            break
                    except ValueError:
                        continue
        
        # Look for dates
        for pattern in date_patterns:
            match = re.search(pattern, line_lower)
            if match:
                date_str = match.group(1)
                try:
                    # Try different date formats
                    for fmt in ['%d/%m/%Y', '%d/%m/%y', '%d-%m-%Y', '%d-%m-%y', '%Y-%m-%d']:
                        try:
                            parsed_date = datetime.strptime(date_str, fmt).date()
                            extracted_data['date'] = parsed_date
                            break
                        except ValueError:
                            continue
                    if extracted_data['date']:
                        break
                except:
                    continue
        
        # Look for times
        for pattern in time_patterns:
            match = re.search(pattern, line_lower)
            if match:
                time_str = match.group(1)
                try:
                    # Try different time formats
                    for fmt in ['%H:%M:%S', '%H:%M', '%I:%M:%S %p', '%I:%M %p']:
                        try:
                            parsed_time = datetime.strptime(time_str, fmt).time()
                            extracted_data['time'] = parsed_time
                            break
                        except ValueError:
                            continue
                    if extracted_data['time']:
                        break
                except:
                    continue
        
        # Look for bill numbers
        for pattern in bill_patterns:
            match = re.search(pattern, line_lower)
            if match:
                bill_num = match.group(1)
                extracted_data['bill_number'] = bill_num
                break
    
    # Try to extract merchant name from first few lines
    for i, line in enumerate(lines[:5]):
        line = line.strip()
        if line and len(line) > 3 and not re.search(r'\d', line):
            # Skip lines with numbers (likely amounts)
            if not any(char.isdigit() for char in line):
                extracted_data['merchant_name'] = line
                break
    
    # Fallback: if no total_amount found, pick the largest number in the text
    if not extracted_data['total_amount']:
        all_numbers = re.findall(r'([0-9]+\.?[0-9]*)', text.replace(',', ''))
        all_numbers = [float(n) for n in all_numbers if n and float(n) > 0]
        if all_numbers:
            extracted_data['total_amount'] = max(all_numbers)
    
    return extracted_data

def process_bill_scan(bill_scan_instance):
    """
    Process a bill scan and extract data
    """
    try:
        image_path = bill_scan_instance.bill_image.path
        
        # Try Tesseract first
        text, confidence = extract_text_with_tesseract(image_path)
        
        # If Tesseract fails or has low confidence, try EasyOCR
        if not text or confidence < 0.3:
            text, confidence = extract_text_with_easyocr(image_path)
        
        if not text:
            bill_scan_instance.status = 'failed'
            bill_scan_instance.processing_notes = 'No text could be extracted from the image'
            bill_scan_instance.save()
            return False
        
        # Extract bill data
        extracted_data = extract_bill_data(text)

        # Convert float values to Decimal for decimal fields
        decimal_fields = ['total_amount', 'subtotal', 'tax_amount']
        for field in decimal_fields:
            value = extracted_data.get(field)
            if value is not None:
                try:
                    logger.debug(f"Converting field '{field}' with value '{value}' (type: {type(value)}) to Decimal.")
                    dec_value = Decimal(str(value))
                    # Check for NaN, infinite, and max 2 decimal places
                    if dec_value.is_nan() or dec_value.is_infinite():
                        logger.warning(f"Rejected value for '{field}': {dec_value} (NaN or infinite)")
                        extracted_data[field] = None
                    elif dec_value.as_tuple().exponent < -2:
                        logger.warning(f"Rejected value for '{field}': {dec_value} (more than 2 decimal places)")
                        extracted_data[field] = None
                    else:
                        extracted_data[field] = dec_value
                except (InvalidOperation, ValueError) as e:
                    logger.warning(f"Failed to convert field '{field}' with value '{value}' to Decimal: {e}")
                    extracted_data[field] = None
        
        # Update bill scan instance
        bill_scan_instance.raw_text = text
        bill_scan_instance.confidence_score = confidence
        
        # Update extracted fields
        for field, value in extracted_data.items():
            if value is not None:
                setattr(bill_scan_instance, field, value)
        
        # Final safety check before saving: ensure decimal fields are valid
        for field in decimal_fields:
            value = getattr(bill_scan_instance, field, None)
            if value is not None:
                try:
                    dec_value = Decimal(str(value))
                    if dec_value.is_nan() or dec_value.is_infinite() or dec_value.as_tuple().exponent < -2:
                        logger.warning(f"Final safety: Field '{field}' had invalid value '{value}' before save (NaN, infinite, or too many decimals). Setting to None.")
                        setattr(bill_scan_instance, field, None)
                except (InvalidOperation, ValueError, TypeError) as e:
                    logger.warning(f"Final safety: Field '{field}' had invalid value '{value}' before save: {e}. Setting to None.")
                    setattr(bill_scan_instance, field, None)
        
        # Set status based on whether we found key data
        if extracted_data.get('total_amount'):
            bill_scan_instance.status = 'processed'
            bill_scan_instance.processing_notes = f'Successfully extracted data with {confidence:.2%} confidence'
        else:
            bill_scan_instance.status = 'failed'
            bill_scan_instance.processing_notes = f'Could not extract total amount. Confidence: {confidence:.2%}'

        # DEBUG: Print values before saving
        print("DEBUG: About to save BillScan with total_amount:", bill_scan_instance.total_amount,
              "subtotal:", bill_scan_instance.subtotal,
              "tax_amount:", bill_scan_instance.tax_amount)
        
        bill_scan_instance.save()
        return True
        
    except Exception as e:
        logger.error(f"Error processing bill scan: {e}")
        bill_scan_instance.status = 'failed'
        bill_scan_instance.processing_notes = f'Processing error: {str(e)}'
        bill_scan_instance.save()
        return False

def create_expense_from_bill(bill_scan_instance, user, category='Other', description=None):
    """
    Create an expense entry from a bill scan
    """
    from expenses.models import Expense
    from datetime import date
    # Ensure total_amount is present and valid
    if not bill_scan_instance.total_amount or bill_scan_instance.total_amount == 0:
        # Do not create expense if amount is missing or zero
        return None
    # Ensure category and description are set
    category = category or 'Other'
    description = description or f"Scanned bill - {bill_scan_instance.merchant_name or 'Unknown'}"
    # Use today's date if missing
    expense_date = bill_scan_instance.date or date.today()
    # Create the expense
    try:
        expense = Expense.objects.create(
            user=user,
            category=category,
            amount=bill_scan_instance.total_amount,
            description=description,
            date=expense_date,
        )
        # Link the expense to the bill scan
        bill_scan_instance.expense = expense
        bill_scan_instance.expense_created = True
        bill_scan_instance.save()
        return expense
    except Exception as e:
        import traceback
        traceback.print_exc()
        return None

# Merchant to category mapping for smart defaults
def guess_category(merchant_name, bill_text=None):
    merchant_category_map = {
        'domino': 'Food & Dining',
        'swiggy': 'Food & Dining',
        'zomato': 'Food & Dining',
        'pizza': 'Food & Dining',
        'restaurant': 'Food & Dining',
        'hotel': 'Food & Dining',
        'apollo': 'Healthcare',
        'pharmacy': 'Healthcare',
        'hospital': 'Healthcare',
        'reliance': 'Shopping',
        'big bazaar': 'Shopping',
        'petrol': 'Transportation',
        'fuel': 'Transportation',
        'electricity': 'Utilities',
        'water': 'Utilities',
        'bill': 'Utilities',
        'amazon': 'Shopping',
        'flipkart': 'Shopping',
        'bus': 'Transportation',
        'train': 'Transportation',
        'movie': 'Entertainment',
        'cinema': 'Entertainment',
        'multiplex': 'Entertainment',
        # Add more as needed
    }
    if merchant_name:
        name_lower = merchant_name.lower()
        for keyword, category in merchant_category_map.items():
            if keyword in name_lower:
                return category
    if bill_text:
        text_lower = bill_text.lower()
        for keyword, category in merchant_category_map.items():
            if keyword in text_lower:
                return category
    return 'Other' 