from django.db import models
from django.contrib.auth.models import User
from django.utils import timezone
import uuid

class UPIID(models.Model):
    """Model to store UPI IDs for users"""
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='upi_id')
    upi_id = models.CharField(max_length=50, unique=True, help_text="UPI ID (e.g., username@bank)")
    display_name = models.CharField(max_length=100, help_text="Display name for the UPI ID")
    is_primary = models.BooleanField(default=True, help_text="Primary UPI ID for the user")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username} - {self.upi_id}"

    class Meta:
        verbose_name = "UPI ID"
        verbose_name_plural = "UPI IDs"

class UPITransaction(models.Model):
    """Model to store UPI transactions"""
    TRANSACTION_STATUS = [
        ('pending', 'Pending'),
        ('success', 'Success'),
        ('failed', 'Failed'),
        ('cancelled', 'Cancelled'),
    ]

    TRANSACTION_TYPE = [
        ('send', 'Send Money'),
        ('receive', 'Receive Money'),
        ('request', 'Request Money'),
    ]

    transaction_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_transactions')
    receiver_upi = models.CharField(max_length=50, help_text="Receiver's UPI ID")
    receiver_name = models.CharField(max_length=100, blank=True, null=True)
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    transaction_type = models.CharField(max_length=10, choices=TRANSACTION_TYPE, default='send')
    status = models.CharField(max_length=10, choices=TRANSACTION_STATUS, default='pending')
    description = models.TextField(blank=True, null=True)
    upi_reference = models.CharField(max_length=50, blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(blank=True, null=True)

    def __str__(self):
        return f"{self.transaction_id} - {self.sender.username} to {self.receiver_upi}"

    class Meta:
        ordering = ['-created_at']

class PaymentRequest(models.Model):
    """Model to store payment requests"""
    REQUEST_STATUS = [
        ('pending', 'Pending'),
        ('accepted', 'Accepted'),
        ('rejected', 'Rejected'),
        ('expired', 'Expired'),
    ]

    request_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    requester = models.ForeignKey(User, on_delete=models.CASCADE, related_name='payment_requests_sent')
    recipient = models.ForeignKey(User, on_delete=models.CASCADE, related_name='payment_requests_received')
    amount = models.DecimalField(max_digits=10, decimal_places=2)
    description = models.TextField(blank=True, null=True)
    status = models.CharField(max_length=10, choices=REQUEST_STATUS, default='pending')
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    expires_at = models.DateTimeField()

    def __str__(self):
        return f"{self.request_id} - {self.requester.username} to {self.recipient.username}"

    class Meta:
        ordering = ['-created_at']

class QRCode(models.Model):
    """Model to store generated QR codes"""
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='qr_codes')
    upi_id = models.CharField(max_length=50)
    amount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    qr_code_image = models.ImageField(upload_to='qr_codes/', blank=True, null=True)
    qr_data = models.TextField(help_text="UPI URL data for QR code")
    created_at = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.user.username} - {self.upi_id} - {self.amount}"

    class Meta:
        ordering = ['-created_at']

class BillScan(models.Model):
    """Model to store scanned bills and extracted data"""
    BILL_STATUS = [
        ('pending', 'Pending'),
        ('processed', 'Processed'),
        ('failed', 'Failed'),
    ]

    scan_id = models.UUIDField(default=uuid.uuid4, editable=False, unique=True)
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bill_scans')
    bill_image = models.ImageField(upload_to='bill_scans/', help_text="Scanned bill image")
    
    # Extracted data
    merchant_name = models.CharField(max_length=200, blank=True, null=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    subtotal = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    tax_amount = models.DecimalField(max_digits=10, decimal_places=2, blank=True, null=True)
    date = models.DateField(blank=True, null=True)
    time = models.TimeField(blank=True, null=True)
    bill_number = models.CharField(max_length=50, blank=True, null=True)
    
    # OCR and processing data
    raw_text = models.TextField(blank=True, null=True, help_text="Raw OCR text from bill")
    confidence_score = models.FloatField(default=0.0, help_text="OCR confidence score")
    
    # Status and processing
    status = models.CharField(max_length=10, choices=BILL_STATUS, default='pending')
    processing_notes = models.TextField(blank=True, null=True)
    
    # Expense integration
    expense_created = models.BooleanField(default=False, help_text="Whether expense was created from this scan")
    expense = models.ForeignKey('expenses.Expense', on_delete=models.SET_NULL, blank=True, null=True, related_name='bill_scan')
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.scan_id} - {self.merchant_name} - {self.total_amount}"

    class Meta:
        ordering = ['-created_at']
        verbose_name = "Bill Scan"
        verbose_name_plural = "Bill Scans"

    @property
    def is_processed(self):
        return self.status == 'processed'

    @property
    def has_expense(self):
        return self.expense_created and self.expense is not None

class BankAccount(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name='bank_accounts')
    bank_name = models.CharField(max_length=100)
    account_number = models.CharField(max_length=20)
    ifsc_code = models.CharField(max_length=15)
    is_primary = models.BooleanField(default=False)
    balance = models.DecimalField(max_digits=12, decimal_places=2, default=0.0)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.bank_name} ({self.account_number[-4:]})"

    class Meta:
        verbose_name = "Bank Account"
        verbose_name_plural = "Bank Accounts"
        unique_together = ('user', 'account_number')

class BillItem(models.Model):
    bill = models.ForeignKey('BillScan', on_delete=models.CASCADE, related_name='items')
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    quantity = models.IntegerField(default=1)
    bought = models.BooleanField(default=True)

    def subtotal(self):
        return self.price * self.quantity

    def __str__(self):
        return f"{self.name} x{self.quantity} (₹{self.price})"
