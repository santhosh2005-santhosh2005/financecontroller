from django.contrib import admin
from .models import UPIID, UPITransaction, PaymentRequest, QRCode, BillScan

@admin.register(UPIID)
class UPIIDAdmin(admin.ModelAdmin):
    list_display = ['user', 'upi_id', 'display_name', 'is_primary', 'created_at']
    list_filter = ['is_primary', 'created_at']
    search_fields = ['user__username', 'user__email', 'upi_id', 'display_name']
    readonly_fields = ['created_at', 'updated_at']
    
    fieldsets = (
        ('User Information', {
            'fields': ('user', 'display_name')
        }),
        ('UPI Details', {
            'fields': ('upi_id', 'is_primary')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )

@admin.register(UPITransaction)
class UPITransactionAdmin(admin.ModelAdmin):
    list_display = ['transaction_id', 'sender', 'receiver_upi', 'amount', 'transaction_type', 'status', 'created_at']
    list_filter = ['status', 'transaction_type', 'created_at']
    search_fields = ['transaction_id', 'sender__username', 'receiver_upi', 'description']
    readonly_fields = ['transaction_id', 'created_at', 'updated_at', 'completed_at']
    
    fieldsets = (
        ('Transaction Information', {
            'fields': ('transaction_id', 'sender', 'receiver_upi', 'receiver_name')
        }),
        ('Payment Details', {
            'fields': ('amount', 'transaction_type', 'description')
        }),
        ('Status Information', {
            'fields': ('status', 'upi_reference')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at', 'completed_at'),
            'classes': ('collapse',)
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('sender')

@admin.register(PaymentRequest)
class PaymentRequestAdmin(admin.ModelAdmin):
    list_display = ['request_id', 'requester', 'recipient', 'amount', 'status', 'created_at', 'expires_at']
    list_filter = ['status', 'created_at', 'expires_at']
    search_fields = ['request_id', 'requester__username', 'recipient__username', 'description']
    readonly_fields = ['request_id', 'created_at', 'updated_at']
    
    fieldsets = (
        ('Request Information', {
            'fields': ('request_id', 'requester', 'recipient')
        }),
        ('Payment Details', {
            'fields': ('amount', 'description')
        }),
        ('Status Information', {
            'fields': ('status', 'expires_at')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('requester', 'recipient')

@admin.register(QRCode)
class QRCodeAdmin(admin.ModelAdmin):
    list_display = ['id', 'user', 'upi_id', 'amount', 'is_active', 'created_at']
    list_filter = ['is_active', 'created_at']
    search_fields = ['user__username', 'upi_id', 'description']
    readonly_fields = ['created_at']
    
    fieldsets = (
        ('QR Code Information', {
            'fields': ('user', 'upi_id', 'amount', 'description')
        }),
        ('QR Code Data', {
            'fields': ('qr_data', 'qr_code_image')
        }),
        ('Status', {
            'fields': ('is_active',)
        }),
        ('Timestamps', {
            'fields': ('created_at',),
            'classes': ('collapse',)
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user')

@admin.register(BillScan)
class BillScanAdmin(admin.ModelAdmin):
    list_display = ['scan_id', 'user', 'merchant_name', 'total_amount', 'status', 'confidence_score', 'created_at']
    list_filter = ['status', 'created_at', 'expense_created']
    search_fields = ['scan_id', 'user__username', 'merchant_name', 'bill_number', 'processing_notes']
    readonly_fields = ['scan_id', 'created_at', 'updated_at', 'confidence_score', 'raw_text']
    
    fieldsets = (
        ('Scan Information', {
            'fields': ('scan_id', 'user', 'bill_image', 'status')
        }),
        ('Extracted Data', {
            'fields': ('merchant_name', 'total_amount', 'subtotal', 'tax_amount', 'date', 'time', 'bill_number')
        }),
        ('OCR Data', {
            'fields': ('raw_text', 'confidence_score', 'processing_notes'),
            'classes': ('collapse',)
        }),
        ('Expense Integration', {
            'fields': ('expense_created', 'expense')
        }),
        ('Timestamps', {
            'fields': ('created_at', 'updated_at'),
            'classes': ('collapse',)
        }),
    )
    
    def get_queryset(self, request):
        return super().get_queryset(request).select_related('user', 'expense')
