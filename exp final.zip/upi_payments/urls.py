from django.urls import path
from . import views
from django.urls import reverse
from django.urls import reverse

app_name = 'upi_payments'

urlpatterns = [
    # Dashboard
    path('', views.upi_dashboard, name='dashboard'),
    
    # UPI ID Management
    path('setup/', views.setup_upi_id, name='setup_upi'),
    
    # Payment Operations
    path('send/', views.send_money, name='send_money'),
    path('request/', views.request_money, name='request_money'),
    path('requests/', views.payment_requests, name='payment_requests'),
    path('requests/<uuid:request_id>/respond/', views.respond_to_request, name='respond_to_request'),
    
    # QR Code Operations
    path('qr/generate/', views.generate_qr, name='generate_qr'),
    path('qr/scan/', views.scan_qr, name='scan_qr'),
    path('qr/amount/<str:qr_data>/', views.enter_amount, name='enter_amount'),
    path('qr/<int:qr_id>/', views.qr_code_detail, name='qr_code_detail'),
    
    # Bill Scanning Operations
    path('bill/scan/', views.scan_bill, name='scan_bill'),
    path('bill/<uuid:scan_id>/', views.bill_detail, name='bill_detail'),
    path('bill/<uuid:scan_id>/edit/', views.edit_bill, name='edit_bill'),
    path('bill/<uuid:scan_id>/create-expense/', views.create_expense_from_bill_view, name='create_expense_from_bill'),
    path('bill/history/', views.bill_history, name='bill_history'),
    path('bill/<uuid:scan_id>/pdf/', views.download_bill_pdf, name='download_bill_pdf'),
    path('bill/<uuid:scan_id>/category/', views.scan_bill_category, name='scan_bill_category'),
    
    # Transaction Management
    path('transactions/', views.transaction_history, name='transaction_history'),
    path('transactions/<uuid:transaction_id>/', views.transaction_detail, name='transaction_detail'),
    
    # API Endpoints
    path('api/process-qr/', views.process_qr_scan, name='process_qr_scan'),
    path('api/process-bill/', views.process_bill_scan_api, name='process_bill_scan_api'),
    path('api/balance/', views.get_balance, name='get_balance'),
    path('shop/', views.shop_mode, name='shop_mode'),
    
    # Bank Account Management
    path('bank-accounts/', views.bank_accounts, name='bank_accounts'),
    path('bank-accounts/add/', views.add_bank_account, name='add_bank_account'),
    path('bank-accounts/<int:pk>/edit/', views.edit_bank_account, name='edit_bank_account'),
] 