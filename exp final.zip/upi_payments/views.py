from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse, HttpResponse, FileResponse, Http404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_methods
from django.core.paginator import Paginator
from django.db.models import Q
from django.utils import timezone
from datetime import timedelta
import json
from decimal import Decimal
import ast
from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
from django.urls import reverse

from .models import UPIID, UPITransaction, PaymentRequest, QRCode, BillScan, BankAccount
from .forms import (
    UPIIDForm, SendMoneyForm, RequestMoneyForm, 
    QRCodeForm, QRCodeScanForm, UPIAmountForm, BillScanForm, BillEditForm,
    CalculatorForm, ShoppingCartItemForm, BankAccountForm
)
from .utils import (
    generate_upi_url, parse_upi_url, generate_qr_code,
    validate_upi_id, format_amount, process_upi_payment,
    get_user_upi_balance, is_valid_qr_code, create_qr_code_file,
    process_bill_scan, create_expense_from_bill, guess_category
)

@login_required
def upi_dashboard(request):
    """Main UPI dashboard"""
    try:
        user_upi = request.user.upi_id
    except UPIID.DoesNotExist:
        user_upi = None
    
    # Get recent transactions
    recent_transactions = UPITransaction.objects.filter(
        sender=request.user
    ).order_by('-created_at')[:5]
    
    # Get pending payment requests
    pending_requests = PaymentRequest.objects.filter(
        recipient=request.user,
        status='pending'
    ).order_by('-created_at')[:5]
    
    # Get user balance (simulated)
    balance = get_user_upi_balance(request.user)
    
    # Get user's bank accounts
    bank_accounts = request.user.bank_accounts.all()
    
    context = {
        'user_upi': user_upi,
        'recent_transactions': recent_transactions,
        'pending_requests': pending_requests,
        'balance': balance,
        'bank_accounts': bank_accounts,
    }
    
    return render(request, 'upi_payments/dashboard.html', context)

@login_required
def setup_upi_id(request):
    """Setup or update UPI ID"""
    try:
        upi_instance = request.user.upi_id
        is_update = True
    except UPIID.DoesNotExist:
        upi_instance = None
        is_update = False
    
    if request.method == 'POST':
        form = UPIIDForm(request.POST, instance=upi_instance)
        if form.is_valid():
            upi_id = form.save(commit=False)
            upi_id.user = request.user
            upi_id.save()
            messages.success(request, f"UPI ID {'updated' if is_update else 'created'} successfully!")
            return redirect('upi_payments:dashboard')
    else:
        form = UPIIDForm(instance=upi_instance)
    
    context = {
        'form': form,
        'is_update': is_update,
    }
    
    return render(request, 'upi_payments/setup_upi.html', context)

@login_required
def send_money(request):
    """Send money via UPI"""
    if not hasattr(request.user, 'upi_id'):
        messages.error(request, "Please setup your UPI ID first!")
        return redirect('upi_payments:setup_upi')
    
    if request.method == 'POST':
        form = SendMoneyForm(request.POST)
        if form.is_valid():
            receiver_upi = form.cleaned_data['receiver_upi']
            amount = form.cleaned_data['amount']
            description = form.cleaned_data['description']
            
            # Process payment
            transaction = process_upi_payment(
                sender=request.user,
                receiver_upi=receiver_upi,
                amount=amount,
                description=description
            )
            
            if transaction.status == 'success':
                messages.success(request, f"Payment of {format_amount(amount)} sent successfully!")
            else:
                messages.error(request, "Payment failed. Please try again.")
            
            return redirect('upi_payments:transaction_detail', transaction_id=transaction.transaction_id)
    else:
        form = SendMoneyForm()
    
    context = {
        'form': form,
    }
    
    return render(request, 'upi_payments/send_money.html', context)

@login_required
def generate_qr(request):
    """Generate QR code for receiving money"""
    if not hasattr(request.user, 'upi_id'):
        messages.error(request, "Please setup your UPI ID first!")
        return redirect('upi_payments:setup_upi')
    
    if request.method == 'POST':
        form = QRCodeForm(request.POST)
        if form.is_valid():
            amount = form.cleaned_data.get('amount')
            description = form.cleaned_data.get('description')
            
            # Generate UPI URL
            upi_url = generate_upi_url(
                upi_id=request.user.upi_id.upi_id,
                amount=amount,
                description=description,
                name=request.user.upi_id.display_name
            )
            
            # Create QR code
            qr_code = create_qr_code_file(
                upi_url=upi_url,
                user=request.user,
                amount=amount,
                description=description
            )
            
            return redirect('upi_payments:qr_code_detail', qr_id=qr_code.id)
    else:
        form = QRCodeForm()
    
    context = {
        'form': form,
    }
    
    return render(request, 'upi_payments/generate_qr.html', context)

@login_required
def scan_qr(request):
    """Scan QR code to pay"""
    if not hasattr(request.user, 'upi_id'):
        messages.error(request, "Please setup your UPI ID first!")
        return redirect('upi_payments:setup_upi')
    
    if request.method == 'POST':
        form = QRCodeScanForm(request.POST)
        if form.is_valid():
            qr_data = form.cleaned_data.get('qr_code_data')
            scanned_amount = form.cleaned_data.get('scanned_amount')
            scanned_upi = form.cleaned_data.get('scanned_upi')
            description = form.cleaned_data.get('description')
            
            if qr_data and is_valid_qr_code(qr_data):
                # Parse QR data
                parsed_data = parse_upi_url(qr_data)
                if parsed_data:
                    receiver_upi = parsed_data['upi_id']
                    amount = scanned_amount or parsed_data.get('amount')
                    
                    if amount:
                        # Process payment
                        transaction = process_upi_payment(
                            sender=request.user,
                            receiver_upi=receiver_upi,
                            amount=amount,
                            description=description
                        )
                        
                        if transaction.status == 'success':
                            messages.success(request, f"Payment of {format_amount(amount)} sent successfully!")
                        else:
                            messages.error(request, "Payment failed. Please try again.")
                        
                        return redirect('upi_payments:transaction_detail', transaction_id=transaction.transaction_id)
                    else:
                        # QR code without amount, redirect to amount entry
                        return redirect('upi_payments:enter_amount', qr_data=qr_data)
                else:
                    messages.error(request, "Invalid QR code format.")
            else:
                messages.error(request, "Please scan a valid QR code.")
    else:
        form = QRCodeScanForm()
    
    context = {
        'form': form,
    }
    
    return render(request, 'upi_payments/scan_qr.html', context)

@login_required
def enter_amount(request, qr_data):
    """Enter amount after scanning QR code without amount"""
    if request.method == 'POST':
        form = UPIAmountForm(request.POST)
        if form.is_valid():
            amount = form.cleaned_data['amount']
            description = form.cleaned_data['description']
            
            # Parse QR data
            parsed_data = parse_upi_url(qr_data)
            if parsed_data:
                receiver_upi = parsed_data['upi_id']
                
                # Process payment
                transaction = process_upi_payment(
                    sender=request.user,
                    receiver_upi=receiver_upi,
                    amount=amount,
                    description=description
                )
                
                if transaction.status == 'success':
                    messages.success(request, f"Payment of {format_amount(amount)} sent successfully!")
                else:
                    messages.error(request, "Payment failed. Please try again.")
                
                return redirect('upi_payments:transaction_detail', transaction_id=transaction.transaction_id)
    else:
        form = UPIAmountForm()
    
    context = {
        'form': form,
        'qr_data': qr_data,
    }
    
    return render(request, 'upi_payments/enter_amount.html', context)

@login_required
def request_money(request):
    """Request money from another user"""
    if request.method == 'POST':
        form = RequestMoneyForm(request.POST)
        if form.is_valid():
            payment_request = form.save(commit=False)
            payment_request.requester = request.user
            payment_request.expires_at = timezone.now() + timedelta(days=7)
            payment_request.save()
            
            messages.success(request, "Payment request sent successfully!")
            return redirect('upi_payments:payment_requests')
    else:
        form = RequestMoneyForm()
    
    context = {
        'form': form,
    }
    
    return render(request, 'upi_payments/request_money.html', context)

@login_required
def payment_requests(request):
    """View payment requests"""
    sent_requests = PaymentRequest.objects.filter(requester=request.user).order_by('-created_at')
    received_requests = PaymentRequest.objects.filter(recipient=request.user).order_by('-created_at')
    
    context = {
        'sent_requests': sent_requests,
        'received_requests': received_requests,
    }
    
    return render(request, 'upi_payments/payment_requests.html', context)

@login_required
def respond_to_request(request, request_id):
    """Respond to payment request (accept/reject)"""
    payment_request = get_object_or_404(PaymentRequest, request_id=request_id, recipient=request.user)
    
    if request.method == 'POST':
        action = request.POST.get('action')
        
        if action == 'accept':
            # Process payment
            transaction = process_upi_payment(
                sender=request.user,
                receiver_upi=payment_request.requester.upi_id.upi_id,
                amount=payment_request.amount,
                description=payment_request.description
            )
            
            if transaction.status == 'success':
                payment_request.status = 'accepted'
                payment_request.save()
                messages.success(request, f"Payment of {format_amount(payment_request.amount)} sent successfully!")
            else:
                messages.error(request, "Payment failed. Please try again.")
                
        elif action == 'reject':
            payment_request.status = 'rejected'
            payment_request.save()
            messages.success(request, "Payment request rejected.")
        
        return redirect('upi_payments:payment_requests')
    
    context = {
        'payment_request': payment_request,
    }
    
    return render(request, 'upi_payments/respond_to_request.html', context)

@login_required
def transaction_history(request):
    """View transaction history"""
    transactions = UPITransaction.objects.filter(sender=request.user).order_by('-created_at')
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        transactions = transactions.filter(
            Q(receiver_upi__icontains=search_query) |
            Q(description__icontains=search_query) |
            Q(transaction_id__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(transactions, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
    }
    
    return render(request, 'upi_payments/transaction_history.html', context)

@login_required
def transaction_detail(request, transaction_id):
    """View transaction details"""
    transaction = get_object_or_404(UPITransaction, transaction_id=transaction_id, sender=request.user)
    
    context = {
        'transaction': transaction,
    }
    
    return render(request, 'upi_payments/transaction_detail.html', context)

@login_required
def qr_code_detail(request, qr_id):
    """View generated QR code details"""
    qr_code = get_object_or_404(QRCode, id=qr_id, user=request.user)
    
    context = {
        'qr_code': qr_code,
    }
    
    return render(request, 'upi_payments/qr_code_detail.html', context)

# API endpoints for AJAX requests
@login_required
@csrf_exempt
@require_http_methods(["POST"])
def process_qr_scan(request):
    """Process QR code scan via AJAX"""
    try:
        data = json.loads(request.body)
        qr_data = data.get('qr_data')
        
        if not qr_data:
            return JsonResponse({'error': 'No QR data provided'}, status=400)
        
        if not is_valid_qr_code(qr_data):
            return JsonResponse({'error': 'Invalid QR code format'}, status=400)
        
        # Parse QR data
        parsed_data = parse_upi_url(qr_data)
        if parsed_data:
            return JsonResponse({
                'success': True,
                'upi_id': parsed_data['upi_id'],
                'name': parsed_data.get('name'),
                'amount': parsed_data.get('amount'),
                'description': parsed_data.get('description'),
            })
        else:
            return JsonResponse({'error': 'Could not parse QR code data'}, status=400)
            
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def get_balance(request):
    """Get user balance via AJAX"""
    balance = get_user_upi_balance(request.user)
    return JsonResponse({'balance': balance})

# Bill Scanning Views
@login_required
def scan_bill(request):
    """Scan bill and extract data"""
    if request.method == 'POST':
        form = BillScanForm(request.POST, request.FILES)
        if form.is_valid():
            bill_scan = form.save(commit=False)
            bill_scan.user = request.user
            bill_scan.save()
            
            # Process the bill scan
            success = process_bill_scan(bill_scan)
            
            if success and bill_scan.status == 'processed' and bill_scan.total_amount:
                # Ask for category, then create expense and redirect to expense list
                return redirect(reverse('upi_payments:scan_bill_category', kwargs={'scan_id': bill_scan.scan_id}))
            else:
                messages.warning(request, "Bill scan completed but the total amount could not be extracted. Please enter the amount manually.")
                return redirect('upi_payments:edit_bill', scan_id=bill_scan.scan_id)
    else:
        form = BillScanForm()
    
    context = {
        'form': form,
    }
    
    return render(request, 'upi_payments/scan_bill.html', context)

@login_required
def scan_bill_category(request, scan_id):
    bill_scan = get_object_or_404(BillScan, scan_id=scan_id, user=request.user)
    suggested_category = guess_category(bill_scan.merchant_name, bill_scan.raw_text)
    if request.method == 'POST':
        category = request.POST.get('category', suggested_category or 'Other')
        description = request.POST.get('description', f"Scanned bill - {bill_scan.merchant_name or 'Unknown'}")
        print(f"DEBUG: Submitting scanned expense. Amount: {bill_scan.total_amount}, Category: {category}, Description: {description}")
        if not bill_scan.total_amount or bill_scan.total_amount == 0:
            messages.error(request, "Cannot add expense: No valid amount found. Please edit the bill and enter the amount.")
            return redirect('upi_payments:edit_bill', scan_id=bill_scan.scan_id)
        expense = create_expense_from_bill(
            bill_scan_instance=bill_scan,
            user=request.user,
            category=category,
            description=description
        )
        if expense:
            messages.success(request, f"Expense created and added to your list! Amount: ₹{expense.amount}")
            return redirect('expenses:expense_list')
        else:
            messages.error(request, "Failed to create expense. Please check the amount and try again.")
            print("DEBUG: create_expense_from_bill returned None. Likely cause: missing or invalid amount.")
    # Get available categories from expenses app
    try:
        from expenses.models import Expense
        categories = Expense.objects.filter(user=request.user).values_list('category', flat=True).distinct()
        categories = list(set(categories) | {'Food', 'Transport', 'Shopping', 'Bills', 'Other'})
    except:
        categories = ['Food', 'Transport', 'Shopping', 'Bills', 'Other']
    context = {
        'bill_scan': bill_scan,
        'categories': categories,
        'suggested_category': suggested_category,
    }
    return render(request, 'upi_payments/scan_bill_category.html', context)

@login_required
def bill_detail(request, scan_id):
    """View bill scan details"""
    bill_scan = get_object_or_404(BillScan, scan_id=scan_id, user=request.user)
    
    context = {
        'bill_scan': bill_scan,
    }
    
    return render(request, 'upi_payments/bill_detail.html', context)

@login_required
def edit_bill(request, scan_id):
    """Edit extracted bill data"""
    bill_scan = get_object_or_404(BillScan, scan_id=scan_id, user=request.user)
    
    if request.method == 'POST':
        form = BillEditForm(request.POST, instance=bill_scan)
        if form.is_valid():
            bill_scan = form.save()
            bill_scan.status = 'processed'
            bill_scan.save()
            
            messages.success(request, "Bill data updated successfully!")
            return redirect('upi_payments:bill_detail', scan_id=bill_scan.scan_id)
    else:
        form = BillEditForm(instance=bill_scan)
    
    context = {
        'form': form,
        'bill_scan': bill_scan,
    }
    
    return render(request, 'upi_payments/edit_bill.html', context)

@login_required
def create_expense_from_bill_view(request, scan_id):
    """Create expense from bill scan, with smart category suggestion and confirmation step"""
    bill_scan = get_object_or_404(BillScan, scan_id=scan_id, user=request.user)
    # Guess category using merchant name and bill text
    suggested_category = guess_category(bill_scan.merchant_name, bill_scan.raw_text)
    if request.method == 'POST':
        category = request.POST.get('category', suggested_category or 'Other')
        description = request.POST.get('description', f"Scanned bill - {bill_scan.merchant_name or 'Unknown'}")
        expense = create_expense_from_bill(
            bill_scan_instance=bill_scan,
            user=request.user,
            category=category,
            description=description
        )
        if expense:
            messages.success(request, f"Expense created successfully! Amount: ₹{expense.amount}")
            return redirect('expenses:expense_detail', pk=expense.pk)
        else:
            messages.error(request, "Failed to create expense. Please try again.")
    # Get available categories from expenses app
    try:
        from expenses.models import Expense
        categories = Expense.objects.filter(user=request.user).values_list('category', flat=True).distinct()
        categories = list(set(categories) | {'Food', 'Transport', 'Shopping', 'Bills', 'Other'})
    except:
        categories = ['Food', 'Transport', 'Shopping', 'Bills', 'Other']
    context = {
        'bill_scan': bill_scan,
        'categories': categories,
        'suggested_category': suggested_category,
    }
    return render(request, 'upi_payments/create_expense.html', context)

@login_required
def bill_history(request):
    """View bill scan history"""
    bill_scans = BillScan.objects.filter(user=request.user).order_by('-created_at')
    
    # Search functionality
    search_query = request.GET.get('search', '')
    if search_query:
        bill_scans = bill_scans.filter(
            Q(merchant_name__icontains=search_query) |
            Q(bill_number__icontains=search_query) |
            Q(processing_notes__icontains=search_query)
        )
    
    # Pagination
    paginator = Paginator(bill_scans, 20)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)
    
    context = {
        'page_obj': page_obj,
        'search_query': search_query,
    }
    
    return render(request, 'upi_payments/bill_history.html', context)

@login_required
@csrf_exempt
@require_http_methods(["POST"])
def process_bill_scan_api(request):
    """Process bill scan via AJAX"""
    try:
        data = json.loads(request.body)
        scan_id = data.get('scan_id')
        
        if not scan_id:
            return JsonResponse({'error': 'Scan ID required'}, status=400)
        
        bill_scan = get_object_or_404(BillScan, scan_id=scan_id, user=request.user)
        success = process_bill_scan(bill_scan)
        
        if success:
            return JsonResponse({
                'success': True,
                'status': bill_scan.status,
                'total_amount': float(bill_scan.total_amount) if bill_scan.total_amount else None,
                'merchant_name': bill_scan.merchant_name,
                'confidence': bill_scan.confidence_score,
            })
        else:
            return JsonResponse({
                'success': False,
                'error': bill_scan.processing_notes
            })
            
    except json.JSONDecodeError:
        return JsonResponse({'error': 'Invalid JSON data'}, status=400)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=500)

@login_required
def shop_mode(request):
    """Shop mode: calculator + shopping cart interface"""
    cart = request.session.get('shop_cart', [])
    total = sum(Decimal(item['price']) * int(item['quantity']) for item in cart if item.get('bought', True))
    calc_result = None
    calc_error = None

    if request.method == 'POST':
        if 'calc_submit' in request.POST:
            calc_form = CalculatorForm(request.POST)
            if calc_form.is_valid():
                expr = calc_form.cleaned_data['expression']
                try:
                    node = ast.parse(expr, mode='eval')
                    if not all(isinstance(n, (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Num, ast.operator, ast.unaryop)) for n in ast.walk(node)):
                        raise ValueError('Invalid expression')
                    calc_result = eval(compile(node, '<string>', 'eval'))
                except Exception as e:
                    calc_error = f"Invalid expression: {e}"
            item_form = ShoppingCartItemForm()
        elif 'item_submit' in request.POST:
            item_form = ShoppingCartItemForm(request.POST)
            if item_form.is_valid():
                item = item_form.cleaned_data
                cart.append({
                    'name': item['name'],
                    'price': str(item['price']),
                    'quantity': item['quantity'],
                    'bought': item.get('bought', False)
                })
                request.session['shop_cart'] = cart
                return redirect('upi_payments:shop_mode')
            calc_form = CalculatorForm()
        elif 'toggle_bought' in request.POST:
            idx = int(request.POST.get('item_idx'))
            cart[idx]['bought'] = not cart[idx].get('bought', False)
            request.session['shop_cart'] = cart
            return redirect('upi_payments:shop_mode')
        elif 'remove_item' in request.POST:
            idx = int(request.POST.get('item_idx'))
            cart.pop(idx)
            request.session['shop_cart'] = cart
            return redirect('upi_payments:shop_mode')
        elif 'finalize_bill' in request.POST:
            total = sum(Decimal(item['price']) * int(item['quantity']) for item in cart if item.get('bought', True))
            merchant = request.POST.get('merchant', 'Shop')
            from upi_payments.models import BillScan
            bill = BillScan.objects.create(
                user=request.user,
                merchant_name=merchant,
                total_amount=total,
                status='processed',
                expense_created=False
            )
            request.session['shop_cart'] = []
            return redirect('upi_payments:bill_detail', scan_id=bill.scan_id)
        else:
            # Unknown POST, just reset forms
            calc_form = CalculatorForm()
            item_form = ShoppingCartItemForm()
    else:
        calc_form = CalculatorForm()
        item_form = ShoppingCartItemForm()

    context = {
        'calc_form': calc_form,
        'item_form': item_form,
        'cart': cart,
        'total': total,
        'calc_result': calc_result,
        'calc_error': calc_error,
    }
    return render(request, 'upi_payments/shop_mode.html', context)

@login_required
def bank_accounts(request):
    accounts = request.user.bank_accounts.all()
    return render(request, 'upi_payments/bank_accounts.html', {'accounts': accounts})

@login_required
def add_bank_account(request):
    if request.method == 'POST':
        form = BankAccountForm(request.POST)
        if form.is_valid():
            acc = form.save(commit=False)
            acc.user = request.user
            if acc.is_primary:
                # Unset other primary accounts
                request.user.bank_accounts.update(is_primary=False)
            acc.save()
            return redirect('upi_payments:bank_accounts')
    else:
        form = BankAccountForm()
    return render(request, 'upi_payments/add_bank_account.html', {'form': form})

@login_required
def edit_bank_account(request, pk):
    acc = get_object_or_404(BankAccount, pk=pk, user=request.user)
    if request.method == 'POST':
        form = BankAccountForm(request.POST, instance=acc)
        if form.is_valid():
            acc = form.save(commit=False)
            if acc.is_primary:
                request.user.bank_accounts.update(is_primary=False)
            acc.save()
            return redirect('upi_payments:bank_accounts')
    else:
        form = BankAccountForm(instance=acc)
    return render(request, 'upi_payments/edit_bank_account.html', {'form': form, 'acc': acc})

@login_required
def download_bill_pdf(request, scan_id):
    from .models import BillScan
    try:
        bill = BillScan.objects.get(scan_id=scan_id, user=request.user)
    except BillScan.DoesNotExist:
        raise Http404("Bill not found")

    # Prepare PDF
    buffer = BytesIO()
    p = canvas.Canvas(buffer, pagesize=letter)
    width, height = letter
    y = height - 50

    # Title
    p.setFont("Helvetica-Bold", 18)
    p.drawString(50, y, "ExpenseTracker Bill")
    y -= 40

    # Merchant and date
    p.setFont("Helvetica", 12)
    p.drawString(50, y, f"Merchant: {bill.merchant_name or 'N/A'}")
    y -= 25
    p.drawString(50, y, f"Date: {bill.date or bill.created_at.date()}")
    y -= 25

    # Itemized details
    items = bill.items.all()
    if items:
        p.setFont("Helvetica-Bold", 13)
        p.drawString(50, y, "Items:")
        y -= 22
        p.setFont("Helvetica", 11)
        p.drawString(50, y, "Name")
        p.drawString(250, y, "Price")
        p.drawString(320, y, "Qty")
        p.drawString(370, y, "Subtotal")
        y -= 18
        p.line(50, y, 500, y)
        y -= 10
        for item in items:
            if y < 80:
                p.showPage()
                y = height - 50
            p.drawString(50, y, str(item.name))
            p.drawString(250, y, f"₹{item.price}")
            p.drawString(320, y, str(item.quantity))
            p.drawString(370, y, f"₹{item.subtotal()}")
            y -= 18
        y -= 10
        p.line(50, y, 500, y)
        y -= 25
    else:
        p.setFont("Helvetica", 12)
        p.drawString(50, y, "(Detailed items not available for this bill)")
        y -= 20
    # Total
    p.setFont("Helvetica-Bold", 14)
    p.drawString(50, y, f"Total Amount: ₹{bill.total_amount}")
    y -= 35

    # Footer
    p.setFont("Helvetica-Oblique", 10)
    p.drawString(50, 40, "Generated by ExpenseTracker")

    p.showPage()
    p.save()
    buffer.seek(0)
    return FileResponse(buffer, as_attachment=True, filename=f"bill_{bill.scan_id}.pdf")
