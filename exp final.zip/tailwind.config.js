module.exports = {
  darkMode: 'class', // Enable dark mode using the 'dark' class
  content: [
    './templates/**/*.html',
    './static/**/*.js',
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
