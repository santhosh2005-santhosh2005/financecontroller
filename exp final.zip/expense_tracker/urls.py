from django.contrib import admin
from django.urls import path, include
from django.shortcuts import redirect
from django.conf import settings
from django.conf.urls.static import static
from core import views as core_views

def root_redirect(request):
    if request.user.is_authenticated:
        return redirect('core:home')
    else:
        return redirect('users:login')

urlpatterns = [
    path('admin/', admin.site.urls),
    path('users/', include('users.urls', namespace='users')),
    path('expenses/', include('expenses.urls', namespace='expenses')),
    path('core/', include('core.urls', namespace='core')),
    path('emi_calculator/', include('emi_calculator.urls', namespace='emi_calculator')),
    path('blog/', include('blog.urls', namespace='blog')),
    path('upi/', include('upi_payments.urls', namespace='upi_payments')),
    path('', root_redirect, name='root'),
]

# Serve media files during development
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
