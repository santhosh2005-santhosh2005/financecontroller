from django.core.management.base import BaseCommand
from django.contrib.auth.models import User
from users.models import UserProfile

class Command(BaseCommand):
    help = 'Creates a superuser with a UserProfile'

    def handle(self, *args, **options):
        username = input("Username: ")
        email = input("Email: ")
        password = input("Password: ")

        user = User.objects.create_superuser(username, email, password)
        try:
            UserProfile.objects.create(user=user)
            self.stdout.write(self.style.SUCCESS('Superuser with UserProfile created successfully'))
        except Exception as e:
            self.stdout.write(self.style.ERROR(f'Error creating UserProfile: {e}'))
            user.delete()  # Delete the user if UserProfile creation fails
