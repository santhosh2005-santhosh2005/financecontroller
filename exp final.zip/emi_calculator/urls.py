from django.urls import path
from . import views

app_name = 'emi_calculator'

urlpatterns = [
    path('emi/', views.emi_calculator, name='emi_calculator'),
]
