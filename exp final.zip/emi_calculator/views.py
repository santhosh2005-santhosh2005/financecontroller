from django.shortcuts import render, redirect
from urllib.parse import quote

def emi_calculator(request):
    if request.method == 'POST':
        loan_amount = float(request.POST.get('loanAmount'))
        interest_rate = float(request.POST.get('interestRate'))
        loan_period = float(request.POST.get('loanPeriod'))

        monthly_interest_rate = interest_rate / (12 * 100)
        number_of_payments = loan_period * 12

        emi = (loan_amount * monthly_interest_rate * (1 + monthly_interest_rate)**number_of_payments) / ((1 + monthly_interest_rate)**number_of_payments - 1)

        emi_amount = round(emi, 2)
        
        # Encode the emi_amount for use in the URL
        encoded_emi_amount = quote(str(emi_amount))
        category = request.POST.get('category', '')
        amount = request.POST.get('amount', '')
        encoded_category = quote(category)
        encoded_amount = quote(amount)

        from django.urls import reverse
        return redirect(reverse('expenses:add_expense') + f'?emi_amount={encoded_emi_amount}&category={encoded_category}&amount={encoded_amount}')
    else:
        return render(request, 'emi_calculator/emi_calculator.html')
