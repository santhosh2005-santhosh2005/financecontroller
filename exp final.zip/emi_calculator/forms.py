from django import forms

class EmiCalculatorForm(forms.Form):
    principal = forms.FloatField(label="Principal Amount")
    rate = forms.FloatField(label="Interest Rate")
    time = forms.IntegerField(label="Loan Tenure (in years)")
