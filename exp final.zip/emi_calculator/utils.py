def calculate_emi(principal, rate, time):
    rate = rate / (12 * 100)
    time = time * 12
    emi = (principal * rate * pow(1 + rate, time)) / (pow(1 + rate, time) - 1)
    return emi
